﻿/* 头文件　*/
#include <Windows.h>
/*************************************
* DllMain
**************************************/
BOOL WINAPI DllMain(
	HINSTANCE hinstDLL,  // DLL模块的句柄
	DWORD fdwReason,     // 调用的情况
	LPVOID lpReserved)  // reserved
{
	// 在不同的情况下都会调用DllMain函数，分别处理
	switch (fdwReason)
	{
		// 加载Dll
	case DLL_PROCESS_ATTACH:
	{
		MessageBox(NULL, L"inject", L"inject", MB_OK);
		break;
	}
	// 新建线程
	case DLL_THREAD_ATTACH:
		break;
		// 线程退出
	case DLL_THREAD_DETACH:
		break;
		// 释放Dll
	case DLL_PROCESS_DETACH:

		break;
	}
	return TRUE;
}